@extends('layouts.admin-app') 
@section('content')

<ul class="breadcrumb">
  <li>
    <i class="icon-home"></i>
    <a href="index.html">Home</a>
    <i class="icon-angle-right"></i>
  </li>
  <li><a href="#">Dashboard</a></li>
</ul>
<div class="row-fluid">
  <h3>Welcome to M CRAFT Admin</h3>
</div>
@endsection
