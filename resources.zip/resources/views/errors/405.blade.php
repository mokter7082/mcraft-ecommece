@extends('layouts.app')
@section('pageTitle', '405 Page Not Found Error')
@section('content')
	<section class="error-area">
		<h1>Whoops, looks like something went wrong.</h1>
	</section>
@endsection
