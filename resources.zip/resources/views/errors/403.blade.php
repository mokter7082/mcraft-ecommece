@extends('layouts.app')
@section('pageTitle', '403 Permission Error')
@section('content')
	<section class="error-area">
		<h1>Sorry, You have not permission to access this page.</h1>
	</section>
@endsection
